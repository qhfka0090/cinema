
function MainVisual(){
    return(
        <section id='main_visual'>
            <div className="inner">
                <img src='/images/main_visual.jpg' alt='' />
            </div>
        </section>
    )
}
export default MainVisual;